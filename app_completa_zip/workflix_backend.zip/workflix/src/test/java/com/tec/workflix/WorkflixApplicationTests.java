package com.tec.workflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkflixApplicationTests {

	@Test
	void contextLoads() {
	}

}
