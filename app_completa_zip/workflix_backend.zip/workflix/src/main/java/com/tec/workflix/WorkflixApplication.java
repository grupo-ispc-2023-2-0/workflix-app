package com.tec.workflix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkflixApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkflixApplication.class, args);
	}
}
